About
===========

Adds a new "Slideshow Type" to Views Slideshow called "FlexSlider".

Usage
======

Enable Views, Views Slideshow and FlexSlider Views Slideshow (note: you do NOT need to enable FlexSlider Views). Create/Edit a View, select a display mode of "Slideshow". In the settings for your display, set the "Slideshow Type" to "FlexSlider", select your option set, set any other options you'd like.

Save your view and you're good to go.